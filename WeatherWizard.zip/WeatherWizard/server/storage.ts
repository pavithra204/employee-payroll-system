import { users, weatherLocations, type User, type InsertUser, type WeatherLocation, type InsertWeatherLocation } from "@shared/schema";
import { db } from "./db";
import { eq, like } from "drizzle-orm";

export interface IStorage {
  getUser(id: number): Promise<User | undefined>;
  getUserByUsername(username: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;
  searchLocations(query: string): Promise<WeatherLocation[]>;
  saveLocation(location: InsertWeatherLocation): Promise<WeatherLocation>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private locations: Map<number, WeatherLocation>;
  private currentUserId: number;
  private currentLocationId: number;

  constructor() {
    this.users = new Map();
    this.locations = new Map();
    this.currentUserId = 1;
    this.currentLocationId = 1;
    
    // Pre-populate with some major cities
    this.seedLocations();
  }

  private seedLocations() {
    const cities = [
      { name: "New York", country: "US", lat: 40.7128, lon: -74.0060, state: "NY" },
      { name: "Los Angeles", country: "US", lat: 34.0522, lon: -118.2437, state: "CA" },
      { name: "Chicago", country: "US", lat: 41.8781, lon: -87.6298, state: "IL" },
      { name: "Houston", country: "US", lat: 29.7604, lon: -95.3698, state: "TX" },
      { name: "Phoenix", country: "US", lat: 33.4484, lon: -112.0740, state: "AZ" },
      { name: "Philadelphia", country: "US", lat: 39.9526, lon: -75.1652, state: "PA" },
      { name: "San Antonio", country: "US", lat: 29.4241, lon: -98.4936, state: "TX" },
      { name: "San Diego", country: "US", lat: 32.7157, lon: -117.1611, state: "CA" },
      { name: "Dallas", country: "US", lat: 32.7767, lon: -96.7970, state: "TX" },
      { name: "San Jose", country: "US", lat: 37.3382, lon: -121.8863, state: "CA" },
      { name: "Austin", country: "US", lat: 30.2672, lon: -97.7431, state: "TX" },
      { name: "Jacksonville", country: "US", lat: 30.3322, lon: -81.6557, state: "FL" },
      { name: "San Francisco", country: "US", lat: 37.7749, lon: -122.4194, state: "CA" },
      { name: "Columbus", country: "US", lat: 39.9612, lon: -82.9988, state: "OH" },
      { name: "Fort Worth", country: "US", lat: 32.7555, lon: -97.3308, state: "TX" },
      { name: "Indianapolis", country: "US", lat: 39.7684, lon: -86.1581, state: "IN" },
      { name: "Charlotte", country: "US", lat: 35.2271, lon: -80.8431, state: "NC" },
      { name: "Seattle", country: "US", lat: 47.6062, lon: -122.3321, state: "WA" },
      { name: "Denver", country: "US", lat: 39.7392, lon: -104.9903, state: "CO" },
      { name: "Boston", country: "US", lat: 42.3601, lon: -71.0589, state: "MA" },
      { name: "London", country: "GB", lat: 51.5074, lon: -0.1278, state: null },
      { name: "Paris", country: "FR", lat: 48.8566, lon: 2.3522, state: null },
      { name: "Tokyo", country: "JP", lat: 35.6762, lon: 139.6503, state: null },
      { name: "Sydney", country: "AU", lat: -33.8688, lon: 151.2093, state: null },
      { name: "Toronto", country: "CA", lat: 43.6532, lon: -79.3832, state: "ON" },
    ];

    cities.forEach(city => {
      const id = this.currentLocationId++;
      const location: WeatherLocation = { 
        id,
        name: city.name,
        country: city.country,
        lat: city.lat,
        lon: city.lon,
        state: city.state ?? null
      };
      this.locations.set(id, location);
    });
  }

  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(
      (user) => user.username === username,
    );
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { ...insertUser, id };
    this.users.set(id, user);
    return user;
  }

  async searchLocations(query: string): Promise<WeatherLocation[]> {
    const searchTerm = query.toLowerCase();
    return Array.from(this.locations.values()).filter(location =>
      location.name.toLowerCase().includes(searchTerm) ||
      location.country.toLowerCase().includes(searchTerm) ||
      (location.state && location.state.toLowerCase().includes(searchTerm))
    ).slice(0, 10); // Limit to 10 results
  }

  async saveLocation(insertLocation: InsertWeatherLocation): Promise<WeatherLocation> {
    const id = this.currentLocationId++;
    const location: WeatherLocation = { 
      id,
      name: insertLocation.name,
      country: insertLocation.country,
      lat: insertLocation.lat,
      lon: insertLocation.lon,
      state: insertLocation.state ?? null
    };
    this.locations.set(id, location);
    return location;
  }
}

export class DatabaseStorage implements IStorage {
  async getUser(id: number): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.id, id));
    return user || undefined;
  }

  async getUserByUsername(username: string): Promise<User | undefined> {
    if (!db) return undefined;
    const [user] = await db.select().from(users).where(eq(users.username, username));
    return user || undefined;
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    if (!db) throw new Error("Database not available");
    const [user] = await db
      .insert(users)
      .values(insertUser)
      .returning();
    return user;
  }

  async searchLocations(query: string): Promise<WeatherLocation[]> {
    if (!db) return [];
    const searchTerm = `%${query.toLowerCase()}%`;
    return await db
      .select()
      .from(weatherLocations)
      .where(
        like(weatherLocations.name, searchTerm)
      )
      .limit(10);
  }

  async saveLocation(insertLocation: InsertWeatherLocation): Promise<WeatherLocation> {
    if (!db) throw new Error("Database not available");
    const [location] = await db
      .insert(weatherLocations)
      .values(insertLocation)
      .returning();
    return location;
  }
}

// Use DatabaseStorage if DATABASE_URL is available, otherwise fall back to MemStorage
export const storage = process.env.DATABASE_URL ? new DatabaseStorage() : new MemStorage();
