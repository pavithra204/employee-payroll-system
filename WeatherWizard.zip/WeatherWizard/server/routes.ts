import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { weatherRequestSchema, citySearchSchema } from "@shared/schema";
import { z } from "zod";

export async function registerRoutes(app: Express): Promise<Server> {
  
  // Get current weather data
  app.get("/api/weather/current", async (req, res) => {
    try {
      const latParam = req.query.lat as string;
      const lonParam = req.query.lon as string;
      
      if (!latParam || !lonParam) {
        return res.status(400).json({ error: "Missing latitude or longitude parameters" });
      }

      const latNum = parseFloat(latParam);
      const lonNum = parseFloat(lonParam);
      
      if (isNaN(latNum) || isNaN(lonNum)) {
        return res.status(400).json({ error: "Invalid latitude or longitude values" });
      }

      const { lat, lon } = weatherRequestSchema.parse({
        lat: latNum,
        lon: lonNum,
      });

      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.OPENWEATHERMAP_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "OpenWeatherMap API key not configured" });
      }

      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/weather?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          return res.status(401).json({ 
            error: "Weather service temporarily unavailable",
            message: "API key is not activated yet. This can take up to 2 hours after OpenWeather account creation."
          });
        }
        return res.status(response.status).json({ error: "Failed to fetch weather data", details: errorData });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid coordinates", details: error.errors });
      }
      console.error("Weather API error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get 5-day forecast
  app.get("/api/weather/forecast", async (req, res) => {
    try {
      const latParam = req.query.lat as string;
      const lonParam = req.query.lon as string;
      
      if (!latParam || !lonParam) {
        return res.status(400).json({ error: "Missing latitude or longitude parameters" });
      }

      const latNum = parseFloat(latParam);
      const lonNum = parseFloat(lonParam);
      
      if (isNaN(latNum) || isNaN(lonNum)) {
        return res.status(400).json({ error: "Invalid latitude or longitude values" });
      }

      const { lat, lon } = weatherRequestSchema.parse({
        lat: latNum,
        lon: lonNum,
      });

      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.OPENWEATHERMAP_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "OpenWeatherMap API key not configured" });
      }

      const response = await fetch(
        `https://api.openweathermap.org/data/2.5/forecast?lat=${lat}&lon=${lon}&appid=${apiKey}&units=metric`
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          return res.status(503).json({ 
            error: "Weather service temporarily unavailable",
            message: "API key is not activated yet. This can take up to 2 hours after OpenWeather account creation."
          });
        }
        return res.status(response.status).json({ error: "Failed to fetch forecast data", details: errorData });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid coordinates", details: error.errors });
      }
      console.error("Forecast API error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Get air quality data
  app.get("/api/weather/air-quality", async (req, res) => {
    try {
      const latParam = req.query.lat as string;
      const lonParam = req.query.lon as string;
      
      if (!latParam || !lonParam) {
        return res.status(400).json({ error: "Missing latitude or longitude parameters" });
      }

      const latNum = parseFloat(latParam);
      const lonNum = parseFloat(lonParam);
      
      if (isNaN(latNum) || isNaN(lonNum)) {
        return res.status(400).json({ error: "Invalid latitude or longitude values" });
      }

      const { lat, lon } = weatherRequestSchema.parse({
        lat: latNum,
        lon: lonNum,
      });

      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.OPENWEATHERMAP_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "OpenWeatherMap API key not configured" });
      }

      const response = await fetch(
        `http://api.openweathermap.org/data/2.5/air_pollution?lat=${lat}&lon=${lon}&appid=${apiKey}`
      );

      if (!response.ok) {
        const errorData = await response.json().catch(() => ({}));
        if (response.status === 401) {
          return res.status(503).json({ 
            error: "Weather service temporarily unavailable",
            message: "API key is not activated yet. This can take up to 2 hours after OpenWeather account creation."
          });
        }
        return res.status(response.status).json({ error: "Failed to fetch air quality data", details: errorData });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid coordinates", details: error.errors });
      }
      console.error("Air quality API error:", error);
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Search cities
  app.get("/api/weather/search", async (req, res) => {
    try {
      const { query } = citySearchSchema.parse({ query: req.query.q as string });
      
      const locations = await storage.searchLocations(query);
      res.json(locations);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid search query", details: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  // Geocoding - get coordinates from city name
  app.get("/api/weather/geocode", async (req, res) => {
    try {
      const queryParam = req.query.q as string;
      
      if (!queryParam || queryParam.length < 1) {
        return res.status(400).json({ error: "Search query is required" });
      }

      const { query } = citySearchSchema.parse({ query: queryParam });

      const apiKey = process.env.OPENWEATHER_API_KEY || process.env.OPENWEATHERMAP_API_KEY;
      if (!apiKey) {
        return res.status(500).json({ error: "OpenWeatherMap API key not configured" });
      }

      const response = await fetch(
        `http://api.openweathermap.org/geo/1.0/direct?q=${encodeURIComponent(query)}&limit=5&appid=${apiKey}`
      );

      if (!response.ok) {
        return res.status(response.status).json({ error: "Failed to geocode location" });
      }

      const data = await response.json();
      res.json(data);
    } catch (error) {
      if (error instanceof z.ZodError) {
        return res.status(400).json({ error: "Invalid search query", details: error.errors });
      }
      res.status(500).json({ error: "Internal server error" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}
