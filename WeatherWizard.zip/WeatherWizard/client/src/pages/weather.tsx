import { useState } from "react";
import WeatherHeader from "@/components/weather/weather-header";
import CurrentWeather from "@/components/weather/current-weather";
import HourlyForecast from "@/components/weather/hourly-forecast";
import WeeklyForecast from "@/components/weather/weekly-forecast";
import AdditionalInfo from "@/components/weather/additional-info";
import LoadingOverlay from "@/components/ui/loading-overlay";
import { useGeolocation } from "@/hooks/use-geolocation";
import { useWeather } from "@/hooks/use-weather";

export default function WeatherPage() {
  const [selectedLocation, setSelectedLocation] = useState<{lat: number, lon: number, name?: string} | null>(null);
  const [temperatureUnit, setTemperatureUnit] = useState<'celsius' | 'fahrenheit'>('fahrenheit');
  const { location: geoLocation, loading: geoLoading, error: geoError } = useGeolocation();
  
  // Use selected location or fall back to geolocation or default to New York
  const currentLocation = selectedLocation || geoLocation || { lat: 40.7128, lon: -74.0060, name: "New York, NY" };
  
  const {
    currentWeather,
    forecast,
    airQuality,
    isLoading: weatherLoading,
    error: weatherError
  } = useWeather(currentLocation);

  const isLoading = geoLoading || weatherLoading;
  const hasError = geoError || weatherError;

  return (
    <div className="min-h-screen weather-gradient">
      <WeatherHeader 
        onLocationSelect={setSelectedLocation}
        temperatureUnit={temperatureUnit}
        onTemperatureUnitChange={setTemperatureUnit}
      />
      
      <main className="max-w-6xl mx-auto px-4 py-6 space-y-6">
        {hasError && (
          <div className="glass-card rounded-3xl p-6 text-center">
            <p className="text-white/80 text-lg">
              Weather service temporarily unavailable
            </p>
            <p className="text-white/60 text-sm mt-2">
              The OpenWeather API key needs to be activated. This can take up to 2 hours after account creation.
            </p>
            <p className="text-white/50 text-xs mt-2">
              Location: {currentLocation ? `${currentLocation.lat}, ${currentLocation.lon}` : 'Unknown'}
            </p>
          </div>
        )}

        {!hasError && currentLocation && (
          <>
            <CurrentWeather 
              data={currentWeather}
              location={currentLocation}
              temperatureUnit={temperatureUnit}
            />
            
            <HourlyForecast 
              data={forecast}
              temperatureUnit={temperatureUnit}
            />
            
            <WeeklyForecast 
              data={forecast}
              temperatureUnit={temperatureUnit}
            />
            
            <AdditionalInfo 
              currentWeather={currentWeather}
              airQuality={airQuality}
            />
          </>
        )}

        {!hasError && !currentLocation && !isLoading && (
          <div className="glass-card rounded-3xl p-8 text-center">
            <h2 className="text-white text-2xl font-bold mb-4">Welcome to WeatherNow</h2>
            <p className="text-white/80 text-lg mb-6">
              Please allow location access or search for a city to get started.
            </p>
          </div>
        )}
      </main>

      <LoadingOverlay isVisible={isLoading} />
    </div>
  );
}
