// Demo data for testing the weather app UI
export const demoCurrentWeather = {
  name: "New York",
  sys: {
    country: "US",
    sunrise: 1735920000,
    sunset: 1735954800
  },
  main: {
    temp: 15.2,
    feels_like: 12.8,
    temp_min: 12.1,
    temp_max: 18.3,
    pressure: 1013,
    humidity: 68
  },
  weather: [
    {
      id: 800,
      main: "Clear",
      description: "clear sky",
      icon: "01d"
    }
  ],
  wind: {
    speed: 3.2,
    deg: 240
  },
  visibility: 10000,
  dt: 1735937200
};

export const demoForecast = {
  list: [
    {
      dt: 1735941600,
      main: {
        temp: 16.1,
        feels_like: 15.2,
        temp_min: 16.1,
        temp_max: 16.1,
        pressure: 1013,
        humidity: 65
      },
      weather: [
        {
          id: 800,
          main: "Clear",
          description: "clear sky",
          icon: "01d"
        }
      ],
      wind: {
        speed: 2.8,
        deg: 250
      }
    },
    {
      dt: 1735952400,
      main: {
        temp: 18.3,
        feels_like: 17.8,
        temp_min: 18.3,
        temp_max: 18.3,
        pressure: 1014,
        humidity: 62
      },
      weather: [
        {
          id: 801,
          main: "Clouds",
          description: "few clouds",
          icon: "02d"
        }
      ],
      wind: {
        speed: 2.5,
        deg: 260
      }
    },
    {
      dt: 1735963200,
      main: {
        temp: 20.1,
        feels_like: 19.5,
        temp_min: 20.1,
        temp_max: 20.1,
        pressure: 1015,
        humidity: 58
      },
      weather: [
        {
          id: 802,
          main: "Clouds",
          description: "scattered clouds",
          icon: "03d"
        }
      ],
      wind: {
        speed: 2.2,
        deg: 270
      }
    },
    {
      dt: 1735974000,
      main: {
        temp: 17.8,
        feels_like: 17.2,
        temp_min: 17.8,
        temp_max: 17.8,
        pressure: 1016,
        humidity: 64
      },
      weather: [
        {
          id: 800,
          main: "Clear",
          description: "clear sky",
          icon: "01n"
        }
      ],
      wind: {
        speed: 2.0,
        deg: 280
      }
    },
    {
      dt: 1735984800,
      main: {
        temp: 14.5,
        feels_like: 13.8,
        temp_min: 14.5,
        temp_max: 14.5,
        pressure: 1017,
        humidity: 70
      },
      weather: [
        {
          id: 800,
          main: "Clear",
          description: "clear sky",
          icon: "01n"
        }
      ],
      wind: {
        speed: 1.8,
        deg: 290
      }
    },
    {
      dt: 1736024400,
      main: {
        temp: 12.8,
        feels_like: 11.9,
        temp_min: 12.8,
        temp_max: 12.8,
        pressure: 1018,
        humidity: 72
      },
      weather: [
        {
          id: 500,
          main: "Rain",
          description: "light rain",
          icon: "10d"
        }
      ],
      wind: {
        speed: 2.5,
        deg: 300
      }
    },
    {
      dt: 1736110800,
      main: {
        temp: 8.2,
        feels_like: 6.5,
        temp_min: 8.2,
        temp_max: 8.2,
        pressure: 1020,
        humidity: 78
      },
      weather: [
        {
          id: 600,
          main: "Snow",
          description: "light snow",
          icon: "13d"
        }
      ],
      wind: {
        speed: 3.2,
        deg: 310
      }
    },
    {
      dt: 1736197200,
      main: {
        temp: 5.1,
        feels_like: 2.8,
        temp_min: 5.1,
        temp_max: 5.1,
        pressure: 1022,
        humidity: 82
      },
      weather: [
        {
          id: 800,
          main: "Clear",
          description: "clear sky",
          icon: "01d"
        }
      ],
      wind: {
        speed: 2.8,
        deg: 320
      }
    }
  ]
};

export const demoAirQuality = {
  list: [
    {
      main: {
        aqi: 2
      },
      components: {
        co: 233.4,
        no: 0.01,
        no2: 13.23,
        o3: 68.66,
        so2: 0.64,
        pm2_5: 8.94,
        pm10: 9.69,
        nh3: 0.52
      }
    }
  ]
};