// Temperature conversion utilities
export function convertTemperature(celsius: number, unit: 'celsius' | 'fahrenheit'): number {
  return unit === 'fahrenheit' ? (celsius * 9/5) + 32 : celsius;
}

// Time formatting utilities
export function formatTime(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    minute: '2-digit',
    hour12: true,
  });
}

export function formatHour(date: Date): string {
  return date.toLocaleTimeString('en-US', {
    hour: 'numeric',
    hour12: true,
  });
}

export function formatDay(date: Date, isToday: boolean = false): string {
  if (isToday) return 'Today';
  
  const tomorrow = new Date();
  tomorrow.setDate(tomorrow.getDate() + 1);
  
  if (date.toDateString() === tomorrow.toDateString()) {
    return 'Tomorrow';
  }
  
  return date.toLocaleDateString('en-US', { weekday: 'long' });
}

// Group forecast data by day
export function groupForecastByDay(forecastList: any[]): any[] {
  const days: { [key: string]: any } = {};
  
  forecastList.forEach(item => {
    const date = new Date(item.dt * 1000);
    const dayKey = date.toDateString();
    
    if (!days[dayKey]) {
      days[dayKey] = {
        date: date,
        temps: [],
        conditions: [],
        icons: [],
        descriptions: []
      };
    }
    
    days[dayKey].temps.push(item.main.temp);
    days[dayKey].conditions.push(item.weather[0].main);
    days[dayKey].icons.push(item.weather[0].icon);
    days[dayKey].descriptions.push(item.weather[0].description);
  });
  
  return Object.values(days).map(day => ({
    date: day.date,
    minTemp: Math.min(...day.temps),
    maxTemp: Math.max(...day.temps),
    condition: getMostCommonCondition(day.conditions),
    icon: getMostCommonIcon(day.icons),
    description: getMostCommonCondition(day.descriptions)
  }));
}

function getMostCommonCondition(conditions: string[]): string {
  const counts: { [key: string]: number } = {};
  conditions.forEach(condition => {
    counts[condition] = (counts[condition] || 0) + 1;
  });
  
  return Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b);
}

function getMostCommonIcon(icons: string[]): string {
  const counts: { [key: string]: number } = {};
  icons.forEach(icon => {
    counts[icon] = (counts[icon] || 0) + 1;
  });
  
  return Object.keys(counts).reduce((a, b) => counts[a] > counts[b] ? a : b);
}
