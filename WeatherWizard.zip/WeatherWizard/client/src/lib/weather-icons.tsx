export function getWeatherIcon(iconCode: string): string {
  const iconMap: { [key: string]: string } = {
    '01d': '☀️', // clear sky day
    '01n': '🌙', // clear sky night
    '02d': '⛅', // few clouds day
    '02n': '☁️', // few clouds night
    '03d': '☁️', // scattered clouds day
    '03n': '☁️', // scattered clouds night
    '04d': '☁️', // broken clouds day
    '04n': '☁️', // broken clouds night
    '09d': '🌧️', // shower rain day
    '09n': '🌧️', // shower rain night
    '10d': '🌦️', // rain day
    '10n': '🌧️', // rain night
    '11d': '⛈️', // thunderstorm day
    '11n': '⛈️', // thunderstorm night
    '13d': '❄️', // snow day
    '13n': '❄️', // snow night
    '50d': '🌫️', // mist day
    '50n': '🌫️', // mist night
  };

  return iconMap[iconCode] || '🌤️';
}

export function getWeatherConditionClass(condition: string): string {
  const conditionMap: { [key: string]: string } = {
    'Clear': 'text-yellow-400',
    'Clouds': 'text-gray-300',
    'Rain': 'text-blue-400',
    'Drizzle': 'text-blue-300',
    'Thunderstorm': 'text-purple-400',
    'Snow': 'text-white',
    'Mist': 'text-gray-400',
    'Smoke': 'text-gray-500',
    'Haze': 'text-yellow-300',
    'Dust': 'text-orange-300',
    'Fog': 'text-gray-400',
    'Sand': 'text-orange-400',
    'Ash': 'text-gray-600',
    'Squall': 'text-gray-500',
    'Tornado': 'text-gray-700',
  };

  return conditionMap[condition] || 'text-blue-400';
}
