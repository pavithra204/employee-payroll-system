import { useQuery } from "@tanstack/react-query";

interface WeatherLocation {
  lat: number;
  lon: number;
  name?: string;
}

export function useWeather(location: WeatherLocation | null) {
  const { data: currentWeather, isLoading: currentLoading, error: currentError } = useQuery({
    queryKey: ['/api/weather/current', location?.lat, location?.lon],
    queryFn: async () => {
      if (!location) throw new Error('No location provided');
      const response = await fetch(`/api/weather/current?lat=${location.lat}&lon=${location.lon}`);
      if (!response.ok) {
        throw new Error('Failed to fetch current weather');
      }
      return response.json();
    },
    enabled: !!location,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: forecast, isLoading: forecastLoading, error: forecastError } = useQuery({
    queryKey: ['/api/weather/forecast', location?.lat, location?.lon],
    queryFn: async () => {
      if (!location) throw new Error('No location provided');
      const response = await fetch(`/api/weather/forecast?lat=${location.lat}&lon=${location.lon}`);
      if (!response.ok) {
        throw new Error('Failed to fetch forecast');
      }
      return response.json();
    },
    enabled: !!location,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  const { data: airQuality, isLoading: airQualityLoading, error: airQualityError } = useQuery({
    queryKey: ['/api/weather/air-quality', location?.lat, location?.lon],
    queryFn: async () => {
      if (!location) throw new Error('No location provided');
      const response = await fetch(`/api/weather/air-quality?lat=${location.lat}&lon=${location.lon}`);
      if (!response.ok) {
        throw new Error('Failed to fetch air quality');
      }
      return response.json();
    },
    enabled: !!location,
    staleTime: 10 * 60 * 1000, // 10 minutes
  });

  return {
    currentWeather,
    forecast,
    airQuality,
    isLoading: currentLoading || forecastLoading || airQualityLoading,
    error: currentError || forecastError || airQualityError,
  };
}
