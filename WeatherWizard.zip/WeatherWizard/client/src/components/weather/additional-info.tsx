import { Sun, Moon } from "lucide-react";
import { formatTime } from "@/lib/weather-api";

interface AdditionalInfoProps {
  currentWeather: any;
  airQuality: any;
}

export default function AdditionalInfo({ currentWeather, airQuality }: AdditionalInfoProps) {
  const getAQILabel = (aqi: number) => {
    switch (aqi) {
      case 1: return { label: "Good", color: "bg-green-500" };
      case 2: return { label: "Fair", color: "bg-yellow-500" };
      case 3: return { label: "Moderate", color: "bg-orange-500" };
      case 4: return { label: "Poor", color: "bg-red-500" };
      case 5: return { label: "Very Poor", color: "bg-purple-500" };
      default: return { label: "Unknown", color: "bg-gray-500" };
    }
  };

  const calculateDaylight = () => {
    if (!currentWeather?.sys?.sunrise || !currentWeather?.sys?.sunset) {
      return "N/A";
    }
    
    const sunrise = new Date(currentWeather.sys.sunrise * 1000);
    const sunset = new Date(currentWeather.sys.sunset * 1000);
    const daylight = sunset.getTime() - sunrise.getTime();
    const hours = Math.floor(daylight / (1000 * 60 * 60));
    const minutes = Math.floor((daylight % (1000 * 60 * 60)) / (1000 * 60));
    
    return `${hours}h ${minutes}m`;
  };

  const getDaylightProgress = () => {
    if (!currentWeather?.sys?.sunrise || !currentWeather?.sys?.sunset) {
      return 0;
    }
    
    const now = new Date();
    const sunrise = new Date(currentWeather.sys.sunrise * 1000);
    const sunset = new Date(currentWeather.sys.sunset * 1000);
    
    if (now < sunrise) return 0;
    if (now > sunset) return 100;
    
    const totalDaylight = sunset.getTime() - sunrise.getTime();
    const elapsed = now.getTime() - sunrise.getTime();
    
    return (elapsed / totalDaylight) * 100;
  };

  return (
    <div className="grid md:grid-cols-2 gap-6">
      <section className="glass-card rounded-3xl p-6 shadow-2xl animate-slide-up">
        <h3 className="text-white font-semibold text-lg mb-4">Sun & Moon</h3>
        <div className="space-y-4">
          {currentWeather?.sys && (
            <>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Sun className="text-orange-400 h-5 w-5" />
                  <span className="text-white/80">Sunrise</span>
                </div>
                <span className="text-white font-semibold">
                  {formatTime(new Date(currentWeather.sys.sunrise * 1000))}
                </span>
              </div>
              <div className="flex items-center justify-between">
                <div className="flex items-center space-x-3">
                  <Moon className="text-yellow-200 h-5 w-5" />
                  <span className="text-white/80">Sunset</span>
                </div>
                <span className="text-white font-semibold">
                  {formatTime(new Date(currentWeather.sys.sunset * 1000))}
                </span>
              </div>
              <div className="w-full h-2 bg-white/20 rounded-full overflow-hidden mt-4">
                <div
                  className="h-full bg-gradient-to-r from-orange-400 to-yellow-300 rounded-full transition-all duration-1000"
                  style={{ width: `${getDaylightProgress()}%` }}
                />
              </div>
              <p className="text-white/70 text-sm text-center">
                {calculateDaylight()} of daylight
              </p>
            </>
          )}
          {!currentWeather?.sys && (
            <p className="text-white/70 text-center">Sun data not available</p>
          )}
        </div>
      </section>
      
      <section className="glass-card rounded-3xl p-6 shadow-2xl animate-slide-up">
        <h3 className="text-white font-semibold text-lg mb-4">Air Quality</h3>
        <div className="space-y-4">
          {airQuality?.list?.[0] ? (
            <>
              <div className="flex items-center justify-between">
                <span className="text-white/80">AQI</span>
                <div className="flex items-center space-x-2">
                  <span className={`px-3 py-1 text-white text-sm rounded-full font-medium ${getAQILabel(airQuality.list[0].main.aqi).color}`}>
                    {getAQILabel(airQuality.list[0].main.aqi).label}
                  </span>
                  <span className="text-white font-semibold">{airQuality.list[0].main.aqi}</span>
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4 mt-4">
                <div>
                  <p className="text-white/70 text-sm">PM2.5</p>
                  <p className="text-white font-semibold">
                    {Math.round(airQuality.list[0].components.pm2_5)} μg/m³
                  </p>
                </div>
                <div>
                  <p className="text-white/70 text-sm">PM10</p>
                  <p className="text-white font-semibold">
                    {Math.round(airQuality.list[0].components.pm10)} μg/m³
                  </p>
                </div>
                <div>
                  <p className="text-white/70 text-sm">O₃</p>
                  <p className="text-white font-semibold">
                    {Math.round(airQuality.list[0].components.o3)} μg/m³
                  </p>
                </div>
                <div>
                  <p className="text-white/70 text-sm">NO₂</p>
                  <p className="text-white font-semibold">
                    {Math.round(airQuality.list[0].components.no2)} μg/m³
                  </p>
                </div>
              </div>
            </>
          ) : (
            <p className="text-white/70 text-center">Air quality data not available</p>
          )}
        </div>
      </section>
    </div>
  );
}
