import { useState, useCallback } from "react";
import { Search, Mic, MapPin } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { useQuery } from "@tanstack/react-query";
import { debounce } from "@/lib/utils";

interface WeatherHeaderProps {
  onLocationSelect: (location: {lat: number, lon: number, name?: string}) => void;
  temperatureUnit: 'celsius' | 'fahrenheit';
  onTemperatureUnitChange: (unit: 'celsius' | 'fahrenheit') => void;
}

export default function WeatherHeader({ 
  onLocationSelect, 
  temperatureUnit, 
  onTemperatureUnitChange 
}: WeatherHeaderProps) {
  const [searchQuery, setSearchQuery] = useState("");
  const [showSuggestions, setShowSuggestions] = useState(false);

  const { data: searchResults } = useQuery({
    queryKey: ['/api/weather/geocode', searchQuery],
    queryFn: async () => {
      const response = await fetch(`/api/weather/geocode?q=${encodeURIComponent(searchQuery)}`);
      if (!response.ok) {
        throw new Error('Failed to fetch search results');
      }
      return response.json();
    },
    enabled: searchQuery.length > 2,
    staleTime: 5 * 60 * 1000, // 5 minutes
  });

  const debouncedSearch = useCallback(
    debounce((value: string) => {
      setSearchQuery(value);
      setShowSuggestions(value.length > 2);
    }, 300),
    []
  );

  const handleSearchInput = (e: React.ChangeEvent<HTMLInputElement>) => {
    const value = e.target.value;
    debouncedSearch(value);
  };

  const handleLocationSelect = (location: any) => {
    onLocationSelect({
      lat: location.lat,
      lon: location.lon,
      name: `${location.name}${location.state ? `, ${location.state}` : ''}, ${location.country}`
    });
    setShowSuggestions(false);
    setSearchQuery("");
  };

  const getCurrentLocation = () => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          onLocationSelect({
            lat: position.coords.latitude,
            lon: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
        }
      );
    }
  };

  const toggleTemperatureUnit = () => {
    onTemperatureUnitChange(temperatureUnit === 'celsius' ? 'fahrenheit' : 'celsius');
  };

  return (
    <header className="bg-white/10 backdrop-blur-md border-b border-white/20 sticky top-0 z-50">
      <div className="max-w-6xl mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center space-x-3">
            <div className="text-2xl">🌤️</div>
            <h1 className="text-xl font-bold text-white">WeatherNow</h1>
          </div>
          
          {/* Search Bar */}
          <div className="flex-1 max-w-md mx-8 relative">
            <div className="relative">
              <Input
                type="text"
                placeholder="Search for a city..."
                onChange={handleSearchInput}
                className="w-full px-4 py-2 pl-10 pr-12 rounded-full bg-white/20 backdrop-blur-sm border border-white/30 text-white placeholder-white/70 focus:outline-none focus:ring-2 focus:ring-white/50 focus:bg-white/30 transition-all duration-300"
              />
              <Search className="absolute left-3 top-1/2 transform -translate-y-1/2 text-white/70 h-4 w-4" />
              <Button
                size="sm"
                variant="ghost"
                className="absolute right-2 top-1/2 transform -translate-y-1/2 p-1 rounded-full hover:bg-white/20 transition-colors"
              >
                <Mic className="text-white/70 h-4 w-4" />
              </Button>
            </div>
            
            {/* Search Suggestions */}
            {showSuggestions && searchResults && searchResults.length > 0 && (
              <div className="absolute top-full left-0 right-0 mt-2 bg-white/90 backdrop-blur-md rounded-2xl border border-white/20 shadow-2xl max-h-60 overflow-y-auto z-50">
                {searchResults.map((location: any, index: number) => (
                  <button
                    key={index}
                    onClick={() => handleLocationSelect(location)}
                    className="w-full px-4 py-3 text-left hover:bg-white/20 transition-colors first:rounded-t-2xl last:rounded-b-2xl flex items-center space-x-2"
                  >
                    <MapPin className="h-4 w-4 text-gray-600" />
                    <span className="text-gray-800">
                      {location.name}
                      {location.state && `, ${location.state}`}
                      , {location.country}
                    </span>
                  </button>
                ))}
              </div>
            )}
          </div>
          
          {/* Temperature Unit Toggle & Location Button */}
          <div className="flex items-center space-x-4">
            <Button
              onClick={getCurrentLocation}
              size="sm"
              variant="ghost"
              className="p-2 rounded-full bg-white/20 hover:bg-white/30 transition-colors"
            >
              <MapPin className="text-white h-4 w-4" />
            </Button>
            
            <div className="flex items-center space-x-2">
              <span className={`text-sm ${temperatureUnit === 'celsius' ? 'text-white font-medium' : 'text-white/70'}`}>
                °C
              </span>
              <button
                onClick={toggleTemperatureUnit}
                className="relative inline-flex h-6 w-11 items-center rounded-full bg-white/20 transition-colors focus:outline-none focus:ring-2 focus:ring-white/50"
              >
                <span 
                  className={`inline-block h-4 w-4 transform rounded-full bg-white transition-transform ${
                    temperatureUnit === 'fahrenheit' ? 'translate-x-6' : 'translate-x-1'
                  }`}
                />
              </button>
              <span className={`text-sm ${temperatureUnit === 'fahrenheit' ? 'text-white font-medium' : 'text-white/70'}`}>
                °F
              </span>
            </div>
          </div>
        </div>
      </div>
    </header>
  );
}
