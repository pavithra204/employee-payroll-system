import { getWeatherIcon } from "@/lib/weather-icons";
import { convertTemperature, formatHour } from "@/lib/weather-api";

interface HourlyForecastProps {
  data: any;
  temperatureUnit: 'celsius' | 'fahrenheit';
}

export default function HourlyForecast({ data, temperatureUnit }: HourlyForecastProps) {
  if (!data || !data.list) return null;

  // Get next 24 hours (8 items * 3 hours each)
  const hourlyData = data.list.slice(0, 8);

  return (
    <section className="glass-card rounded-3xl p-6 shadow-2xl animate-slide-up">
      <h3 className="text-white font-semibold text-lg mb-4">24-Hour Forecast</h3>
      <div className="flex space-x-4 overflow-x-auto pb-2">
        {hourlyData.map((item: any, index: number) => {
          const temperature = convertTemperature(item.main.temp, temperatureUnit);
          return (
            <div
              key={index}
              className="flex-shrink-0 bg-white/10 rounded-2xl p-4 text-center min-w-[80px] backdrop-blur-sm"
            >
              <p className="text-white/70 text-sm mb-2">
                {formatHour(new Date(item.dt * 1000))}
              </p>
              <div className="text-2xl mb-2">
                {getWeatherIcon(item.weather[0].icon)}
              </div>
              <p className="text-white font-semibold">
                {Math.round(temperature)}°
              </p>
            </div>
          );
        })}
      </div>
    </section>
  );
}
