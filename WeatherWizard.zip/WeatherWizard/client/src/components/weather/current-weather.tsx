import { Eye, Droplets, Wind, Gauge } from "lucide-react";
import { getWeatherIcon } from "@/lib/weather-icons";
import { convertTemperature, formatTime } from "@/lib/weather-api";

interface CurrentWeatherProps {
  data: any;
  location: {lat: number, lon: number, name?: string};
  temperatureUnit: 'celsius' | 'fahrenheit';
}

export default function CurrentWeather({ data, location, temperatureUnit }: CurrentWeatherProps) {
  if (!data) return null;

  const temperature = convertTemperature(data.main.temp, temperatureUnit);
  const feelsLike = convertTemperature(data.main.feels_like, temperatureUnit);
  const unit = temperatureUnit === 'celsius' ? '°C' : '°F';

  return (
    <section className="glass-card rounded-3xl p-8 shadow-2xl animate-fade-in">
      <div className="flex items-center justify-between mb-6">
        <div>
          <h2 className="text-white/80 text-lg font-medium mb-1">Current Location</h2>
          <p className="text-white text-2xl font-bold">
            {location.name || `${data.name}, ${data.sys.country}`}
          </p>
          <p className="text-white/70 text-sm">{formatTime(new Date())}</p>
        </div>
      </div>
      
      <div className="grid md:grid-cols-2 gap-8 items-center">
        <div className="text-center md:text-left">
          <div className="flex items-center justify-center md:justify-start space-x-4 mb-4">
            <div className="text-6xl animate-pulse-gentle">
              {getWeatherIcon(data.weather[0].icon)}
            </div>
            <div>
              <div className="text-6xl font-bold text-white">
                {Math.round(temperature)}°
              </div>
              <div className="text-white/80 text-lg capitalize">
                {data.weather[0].description}
              </div>
            </div>
          </div>
          <p className="text-white/70 text-sm mb-4">
            {data.weather[0].main} with {data.weather[0].description}
          </p>
          <div className="flex items-center justify-center md:justify-start space-x-4 text-sm text-white/80">
            <span>Feels like <span className="font-medium">{Math.round(feelsLike)}{unit}</span></span>
            {data.uvi && (
              <>
                <span>•</span>
                <span>UV Index <span className="font-medium">{Math.round(data.uvi)}</span></span>
              </>
            )}
          </div>
        </div>
        
        {/* Weather Metrics Grid */}
        <div className="grid grid-cols-2 gap-4">
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <Eye className="text-blue-300 h-5 w-5" />
              <div>
                <p className="text-white/70 text-sm">Visibility</p>
                <p className="text-white font-semibold">
                  {data.visibility ? `${(data.visibility / 1000).toFixed(1)} km` : 'N/A'}
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <Droplets className="text-blue-300 h-5 w-5" />
              <div>
                <p className="text-white/70 text-sm">Humidity</p>
                <p className="text-white font-semibold">{data.main.humidity}%</p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <Wind className="text-blue-300 h-5 w-5" />
              <div>
                <p className="text-white/70 text-sm">Wind Speed</p>
                <p className="text-white font-semibold">
                  {(data.wind.speed * 2.237).toFixed(1)} mph
                </p>
              </div>
            </div>
          </div>
          
          <div className="bg-white/10 rounded-2xl p-4 backdrop-blur-sm">
            <div className="flex items-center space-x-3">
              <Gauge className="text-blue-300 h-5 w-5" />
              <div>
                <p className="text-white/70 text-sm">Pressure</p>
                <p className="text-white font-semibold">
                  {(data.main.pressure * 0.02953).toFixed(2)} in
                </p>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
