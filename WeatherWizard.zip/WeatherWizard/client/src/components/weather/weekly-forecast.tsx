import { getWeatherIcon } from "@/lib/weather-icons";
import { convertTemperature, formatDay, groupForecastByDay } from "@/lib/weather-api";

interface WeeklyForecastProps {
  data: any;
  temperatureUnit: 'celsius' | 'fahrenheit';
}

export default function WeeklyForecast({ data, temperatureUnit }: WeeklyForecastProps) {
  if (!data || !data.list) return null;

  const dailyData = groupForecastByDay(data.list);
  const unit = temperatureUnit === 'celsius' ? '°C' : '°F';

  return (
    <section className="glass-card rounded-3xl p-6 shadow-2xl animate-slide-up">
      <h3 className="text-white font-semibold text-lg mb-4">5-Day Forecast</h3>
      <div className="space-y-3">
        {dailyData.slice(0, 5).map((day: any, index: number) => {
          const minTemp = convertTemperature(day.minTemp, temperatureUnit);
          const maxTemp = convertTemperature(day.maxTemp, temperatureUnit);
          const tempRange = maxTemp - minTemp;
          const progressPercentage = tempRange > 0 ? ((maxTemp - minTemp) / 40) * 100 : 50; // Normalized to typical range

          return (
            <div
              key={index}
              className="flex items-center justify-between p-4 bg-white/10 rounded-2xl backdrop-blur-sm hover:glass-card-hover transition-all duration-300"
            >
              <div className="flex items-center space-x-4">
                <span className="text-white font-medium w-20">
                  {formatDay(day.date, index === 0)}
                </span>
                <div className="text-2xl w-8 text-center">
                  {getWeatherIcon(day.icon)}
                </div>
                <span className="text-white/80 capitalize">{day.description}</span>
              </div>
              <div className="flex items-center space-x-4">
                <span className="text-white/70">{Math.round(minTemp)}°</span>
                <div className="w-24 h-2 bg-white/20 rounded-full overflow-hidden">
                  <div
                    className="h-full bg-gradient-to-r from-blue-400 to-orange-400 rounded-full"
                    style={{ width: `${Math.min(Math.max(progressPercentage, 20), 100)}%` }}
                  />
                </div>
                <span className="text-white font-semibold">{Math.round(maxTemp)}°</span>
              </div>
            </div>
          );
        })}
      </div>
    </section>
  );
}
