import { pgTable, text, serial, integer, real, timestamp } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  username: text("username").notNull().unique(),
  password: text("password").notNull(),
});

export const weatherLocations = pgTable("weather_locations", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  country: text("country").notNull(),
  lat: real("lat").notNull(),
  lon: real("lon").notNull(),
  state: text("state"),
});

export const insertUserSchema = createInsertSchema(users).pick({
  username: true,
  password: true,
});

export const insertWeatherLocationSchema = createInsertSchema(weatherLocations).omit({
  id: true,
});

export const weatherRequestSchema = z.object({
  lat: z.number(),
  lon: z.number(),
});

export const citySearchSchema = z.object({
  query: z.string().min(1),
});

export type InsertUser = z.infer<typeof insertUserSchema>;
export type User = typeof users.$inferSelect;
export type WeatherLocation = typeof weatherLocations.$inferSelect;
export type InsertWeatherLocation = z.infer<typeof insertWeatherLocationSchema>;
export type WeatherRequest = z.infer<typeof weatherRequestSchema>;
export type CitySearch = z.infer<typeof citySearchSchema>;
